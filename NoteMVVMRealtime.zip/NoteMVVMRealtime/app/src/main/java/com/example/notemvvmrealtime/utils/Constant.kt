package com.example.notemvvmrealtime.utils

object Constant {
    const val NOTES = "notes"
}