package com.example.notemvvmrealtime.model

import androidx.activity.result.contract.ActivityResultContracts

data class  Note(
    val id:String = "",
    val title:String = "",
    val content:String = "",
)